/** Start of a Junit Test Class for Power **/
/*** Add your tests below to cover all statements/branches **/

import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import java.util.*;

public class PowerTest{

private Power myPow;

@Before
    public void setUp() throws Exception {
      Power myPow = new Power();
    }

    
	    
   @Test public void PowTest1(){
	assertEquals(myPow.power(2,5),32);
       
   }
    @Test public void PowTest2(){
	assertEquals(myPow.power(1,2),1);
	
    }


}


