// Introduction to Software Testing
// Authors: Paul Ammann & Jeff Offutt
// Chapter 9; page ??
// Can be run from command line
// No JUnit tests at this time.
//modified by M. Cohen for COMS 417

public class Power
{
   public static int power (int left, int right)
   {
     //**************************************
     // Raises Left to the power of Right
     // precondition : Right >= 0
     // postcondition: Returns Left**Right
     //**************************************

      int rslt;
      rslt = left;

      
      // do some checks to avoid overflow

      if((right <=5 && left <= 10 && left >=0) || (right <=10 && left <=5))
      {
          if(right <=0)
         {
             rslt=-1;
         }
          else
          {

          if (right == 0)
          {
              rslt = 1;
          }
          else
          {
              for (int i = 2; i <= right; i++)
              rslt = rslt * left;
          }
          }
      }   
      else{
      rslt=-1;
      }       
          return (rslt);
     
   }
     public static int inverse (int left, int right)
   {
     //**************************************
     // Raises Left to the power of Right
     // precondition : Right >= 0
     // postcondition: Returns Left**Right
     //**************************************
      int rslt;
      rslt = right;
      if (right == 0)
      {
         rslt = 1;
      }
      else
      {
         for (int i = 2; i <= left; i++)
            rslt = rslt * right;
      }
      return (rslt);
   }


    
}
